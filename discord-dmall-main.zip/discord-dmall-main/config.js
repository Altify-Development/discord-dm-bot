exports.TOKEN = "";
exports.PREFIX = "n.";